package com.example.spring04.model.message;

public interface PointDAO {
	void updatePoint(String userid, int point);
}
