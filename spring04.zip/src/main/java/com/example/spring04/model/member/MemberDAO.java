package com.example.spring04.model.member;

public interface MemberDAO {
	String login(MemberDTO dto);
}
