package com.example.spring04.model.member;

public interface AdminDAO {
	String login(MemberDTO dto);
}
