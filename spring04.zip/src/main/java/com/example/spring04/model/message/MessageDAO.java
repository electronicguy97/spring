package com.example.spring04.model.message;

public interface MessageDAO {
	void create(MessageDTO dto);
}
