package com.example.spring04.service.chart;

import org.jfree.chart.JFreeChart;

public interface JFreeChartService {
	JFreeChart createChart();
}
