package com.example.spring04.service.message;

import com.example.spring04.model.message.MessageDTO;

public interface MessageService {
	void insertMessage(MessageDTO dto);
}
