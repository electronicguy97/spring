package com.example.spring04.service.chart;

import org.json.simple.JSONObject;

public interface GoogleChartService {
	JSONObject getChartData();
}
