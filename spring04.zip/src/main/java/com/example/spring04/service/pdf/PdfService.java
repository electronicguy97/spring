package com.example.spring04.service.pdf;

public interface PdfService {
	String createPdf();
}
